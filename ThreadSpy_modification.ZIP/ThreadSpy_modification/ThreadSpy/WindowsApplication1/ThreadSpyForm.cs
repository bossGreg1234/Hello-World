using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace ThreadSpy
{
 

        /// <summary>
        /// The method to be executed by the new thread
        /// It will print 20 times the character c into TextBox tb
        /// </summary>
       
    public partial class ThreadSpyForm : Form
    {
        private Thread drawingThread;
        private char c = (char)('a'-1);
        int a = 0;
        
        public ThreadSpyForm()
        {
            InitializeComponent();
           
        }
        public void Run()
        {

            for (int i = 0; i <a; i++)
            {
                Thread.Sleep(300);
                TextBoxHelper.AddChar(this.TextBoxOutput, c);
            }
        }

        /// <summary>
        /// This method is called when the user clicks the button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonStartThread_Click(object sender, EventArgs e)
        {
                c = (char)(c + 1);
            a++;
                drawingThread = new Thread(new ThreadStart(Run));
                try
                {
                    drawingThread.Start();
                }
                catch (Exception)
                {

                }
           


    }

        /// <summary>
        /// This method is called 10 times per second by the timer 
        /// to show the current status of the thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (drawingThread != null)
                this.TextBoxStatus.Text = drawingThread.ThreadState.ToString();
        }

    }
}